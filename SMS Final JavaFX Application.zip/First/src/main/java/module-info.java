module sms.first {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;
    requires javafx.swing;


    opens sms.first to javafx.fxml;
    exports sms.first;
}